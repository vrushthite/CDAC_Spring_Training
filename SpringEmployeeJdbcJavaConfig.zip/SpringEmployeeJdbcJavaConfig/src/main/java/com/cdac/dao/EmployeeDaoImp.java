package com.cdac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.EmployeeQueries;
@Repository("dao")
public class EmployeeDaoImp implements EmployeeDao{
	@Autowired
	private JdbcTemplate template;
	
	
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	public int createEmployee(Employee employee) {
		int result=template.update(EmployeeQueries.INSERT_EMPLOYEE_RECORD,employee.getEmployeid(),employee.getSalary(),employee.getName());
		System.out.println("inserted");
		return result;
	}
	public Employee readEmployeeById (int employeeid) {
		
		Employee employee=template.queryForObject(EmployeeQueries.GET_EMPLOYEE_BY_ID,new Object[] {employeeid}, new EmployeeRowMapper());
		
		return employee;
	}
	public List<Employee> readAllEmployee() {
			List<Employee> emplist=template.query(EmployeeQueries.GET_ALL_EMPLOYEE,new EmployeeRowMapper());
		return emplist;
	}
	public int updateEmployee(Employee employee) {
		int result=template.update(EmployeeQueries.UPDATE_EMPLOYEE_BY_ID,employee.getName(),employee.getSalary(),employee.getEmployeid());
		return result;
	}
	public int deleteEmployee(int employeeid) {
		int result =template.update(EmployeeQueries.DELETE_EMPLOYEE_BY_ID,employeeid);
		return result;
	}

}
