package com.cdac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cdac.model.Employee;
import com.cdac.ui.Main;

public class EmployeeRowMapper implements RowMapper<Employee>{

	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee=(Employee) Main.getContext().getBean("employee");
		employee.setName(rs.getString("emp_name"));
		employee.setEmployeid(rs.getInt("emp_id"));
		employee.setSalary(rs.getDouble("emp_salary"));
		return employee;
	}

	
	
}
