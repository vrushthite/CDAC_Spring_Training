package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeDao;
import com.cdac.model.Employee;
@Service("service")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;
	
	
	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	public boolean addEmployee(Employee employee) {
		int result=dao.createEmployee(employee);
		if(result==1) {
			return true;
		}else {
		return false;
		}
	}

	public Employee findEmployeeById(int employeeid) {
		Employee result=dao.readEmployeeById(employeeid);
		return result;
	}

	
	public List<Employee> findAllEmployees() {
		List<Employee> employees=dao.readAllEmployee();
		return employees;
	}

	public boolean modifyEmployee(Employee employee) {
		int result=	dao.updateEmployee(employee);
		if(result==1) {
			return true;
		}else {
		return false;
		}
	}

	public boolean removeEmployee(int employeeid) { 
		int result=	dao.deleteEmployee(employeeid);
		if(result==1) {
			return true;
		}else {
		return false;
		}
	}

}
