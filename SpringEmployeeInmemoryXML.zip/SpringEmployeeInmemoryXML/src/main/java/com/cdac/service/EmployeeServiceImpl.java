package com.cdac.service;

import java.util.List;

import com.cdac.dao.EmployeeDao;
import com.cdac.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao dao;
	
	
	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	public boolean addEmployee(Employee employee) {
		boolean result=dao.createEmployee(employee);
		return result;
	}

	public Employee findEmployeeById(int employeeid) {
		Employee result=dao.readEmployeeById(employeeid);
		return result;
	}

	
	public List<Employee> findAllEmployees() {
		List<Employee> employees=dao.readAllEmployee();
		return employees;
	}

}
