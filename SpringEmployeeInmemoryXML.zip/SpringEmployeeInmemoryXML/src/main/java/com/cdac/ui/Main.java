package com.cdac.ui;

import java.io.ObjectInputStream.GetField;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Config.xml");
		Employee employee=context.getBean("employee",Employee.class);
		EmployeeService service=context.getBean("service",EmployeeService.class);
		
		boolean result=service.addEmployee(employee);
		if(result) {
			System.out.println("employee added");
		}else {
			System.out.println("employee unable to add");
		}
		List<Employee> emp=service.findAllEmployees();
		for(Employee emp1:emp) {
			System.out.println(emp1);
		}
		Employee findemp=service.findEmployeeById(101);
		if(findemp==null) {
			System.out.println("No such employee present");
		}else {
		System.out.println(findemp);
		}
		service.addEmployee(employee);
	}

}
