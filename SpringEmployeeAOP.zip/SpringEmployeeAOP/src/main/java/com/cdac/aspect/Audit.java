package com.cdac.aspect;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Audit {
	@Pointcut("execution(* addEmployee(*))")
	public void pointCut() {
		
	}
	
//	@Before("execution(public * add*(..))")
//	public void auditBeforeAddEmployee(JoinPoint joinPoint) {
//		System.out.println(joinPoint.getSignature().toString());
//		System.out.println("The methods called on date :"+new Date());
//	}
//	@Around("execution(* addEmployee(*))")
//	public Object auditAroundAddEmployee(ProceedingJoinPoint joinPoint) throws Throwable {
//		
//		System.out.println("Some Pre-Processing before execution of addEmployee Method");
//		
//		Object result=joinPoint.proceed();
//			System.out.println("Some Post-Processing before execution of addEmployee Method");
//		
//		return result;
//	}
	@AfterReturning(pointcut="pointCut()",returning="result")
	public void auditAfterReturningAddEmployee(boolean result) {
		
		System.out.println("Method returning -> "+result);
	}
	@AfterThrowing(pointcut="pointCut()",throwing = "result")
	public void auditAfterThrowingAddEmployee(boolean result) {
		
		System.out.println("Method returning -> "+result);
	}
	
	
	
}
