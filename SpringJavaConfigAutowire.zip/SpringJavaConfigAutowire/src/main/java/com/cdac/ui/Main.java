package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.AppConfig;

import com.cdac.model.Employee;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
		
		Employee emp=(Employee)context.getBean("employee2");
		System.out.println(emp);
		System.out.println(emp.getAddress());
		((AnnotationConfigApplicationContext)context).close();
	}

}
