package com.cdac.model;


import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
@Component("employee2")
public class Employee implements InitializingBean,DisposableBean{
private int employeid;   
private String name;
private double salary;
//to automaticly wired the address object from AppConfig as we have 2 different bean of address 
//autowire first search bytype and then search byname
@Autowired
@Qualifier("address2")
private Address address;



public Employee() {
	super();
}

public Employee(int employeid, String name, double salary, Address address) {
	super();
	this.employeid = employeid;
	this.name = name;
	this.salary = salary;
	this.address = address;
}

public int getEmployeid() {
	return employeid;
}
public void setEmployeid(int employeid) {
	this.employeid = employeid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}

public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "Employee [employeid=" + employeid + ", name=" + name + ", salary=" + salary + ", address=" + address + "]";
}
@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("Employee after afterPropertiesSet");
	
}
@Override
public void destroy() throws Exception {
	System.out.println("Employee destroy");

}
@PostConstruct
public void init() throws Exception {
	System.out.println("Employee after init");
	
}
@PreDestroy
public void delete() throws Exception {
	System.out.println("Employee delete");
	
}

}
