package com.cdac.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	@Autowired
	private ApplicationContext context;
	//annotation that binds a method parameter or method return value to a named model attribute, exposed to a web view. 
	@ModelAttribute
	public void getModelAttribute(Model model) {
		 model.addAttribute("employeeForm",context.getBean(Employee.class));
	}
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String homePage() {
		return "index";
	}
	@RequestMapping(path="addEmployee.view", method=RequestMethod.GET)
	public String addEmployeePage(Model model) {
		//model.addAttribute("employeeForm",context.getBean(Employee.class));
		return "addEmployee";
	}
	@RequestMapping(path="addEmployee.do", method=RequestMethod.POST)
	public String addEmployee(@Valid @ModelAttribute("employeeForm") Employee employee,BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "addEmployee";
		}else {
			  boolean result = service.addEmployee(employee); 
			  if(result) { 
				  return "redirect:viewEmployee.do"; 
			  }
			  else{ 
				  return "error"; 
			  }
		}
		 
	}
	@RequestMapping(path="viewEmployee.do", method=RequestMethod.GET)
	public String viewAllEmployees(Model model) {
		//List<Employee> employees = service.findAllEmployees();
		List<Employee> employees = service.findAllEmployeesWithAddress();
		model.addAttribute("employees", employees);
		return "viewEmployees";
	}
	/*
	 * @ExceptionHandler(Exception.class) public String handleException() { return
	 * "Error"; }
	 */
}











