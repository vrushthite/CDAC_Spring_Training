package com.cdac.utils;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtil {
	private static EntityManager entityManager;
	private static EntityManagerFactory factory;
	static {
		
		factory=Persistence.createEntityManagerFactory("JPA_PU"); //persistence-unit name from persistence.xml
		entityManager=factory.createEntityManager();
		
		
	}
	public static EntityManager getEntityManager() {
		return entityManager;
	}

}
