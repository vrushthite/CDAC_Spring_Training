package com.cdac.dao;


import java.util.List;

import javax.persistence.EntityManager;


import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.JpaUtil;

@Repository("dao")
public class EmployeeDaoImp implements EmployeeDao{

	private EntityManager entityManager;
	
	
	public EmployeeDaoImp() {
		entityManager=JpaUtil.getEntityManager();
	}

	public int createEmployee(Employee employee) {
		entityManager.getTransaction().begin();
		entityManager.persist(employee);// return void
		entityManager.getTransaction().commit();
		return 1;
	}

	@Override
	public Employee readEmployeeById(int employeeid) {
		// TODO Auto-generated method stub
		
	Employee employee=	entityManager.find(Employee.class, employeeid);
	return employee;
	}

	@Override
	public List<Employee> readAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
		entityManager.merge(employee);
		entityManager.getTransaction().commit();
		return 1;
	}

	@Override
	public int deleteEmployee(int employeeid) {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
		Employee employee=readEmployeeById(employeeid);
		entityManager.remove(employee);
		entityManager.getTransaction().commit();
		return 1;
	}
	
}
