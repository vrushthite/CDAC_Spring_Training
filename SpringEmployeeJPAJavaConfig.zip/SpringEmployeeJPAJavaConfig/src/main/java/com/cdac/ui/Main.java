package com.cdac.ui;

import java.io.ObjectInputStream.GetField;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	private static ApplicationContext context;
	
	public static ApplicationContext getContext() {
		return context;
	}
	public static void main(String[] args) {
		 context=new AnnotationConfigApplicationContext(AppConfig.class);
		Employee employee=context.getBean("employee",Employee.class);
		EmployeeService service=context.getBean("service",EmployeeService.class);
		//insert data
		 employee.setEmployeid(987);
		employee.setName("Pooja");
		employee.setSalary(123400);
		employee.getAddress().setAddress_id(22);
		employee.getAddress().setCity("Juhu");
		employee.getAddress().setStreet("Gulmohar Road");
		employee.getAddress().setPin("400069");
		boolean result=service.addEmployee(employee);
		if(result) {
			System.out.println("employee added");
		}else {
			System.out.println("employee unable to add");
		}
		
		//Find by id
		Employee findemp=service.findEmployeeById(987);
		if(findemp==null) {
			System.out.println("No such employee present");
		}else {
		System.out.println(findemp);
		}
	/*//Update Operation
		employee.setEmployeid(165);
		employee.setName("praju");
		employee.setSalary(123400);
		boolean result=service.modifyEmployee(employee);
		if(result) {
			System.out.println("Employee is  modified");
		}else {
			System.out.println("Employee is not modified");
		}*/
		
		/*
		 //display all employee
		List<Employee> emplist=service.findAllEmployees();
		for(Employee list:emplist) {
			System.out.println(list);
		}
		boolean result=service.removeEmployee(111);*/
	
	}
}
