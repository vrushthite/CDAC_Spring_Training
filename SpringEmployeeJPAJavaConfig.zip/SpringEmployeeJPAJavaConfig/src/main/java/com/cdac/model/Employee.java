package com.cdac.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Entity
@Table(name="employee2")
@Component("employee")
@Scope(scopeName = "prototype")
public class Employee implements Serializable {
	@Id
	@Column(name="emp_id")
	private int employeid;
	@Column(name="emp_name")
	private String name;
	@Column(name="emp_salary")
	private double salary;
	
	//owner entity
	@OneToOne(cascade = CascadeType.ALL)       //dependent class also get affected by cascade type
	@JoinColumn(name = "address_id")
	@Autowired
	private Address address;
	
	
	
	public Employee() {
		super();
	}
	
	public Employee(int employeid, String name, double salary, Address address) {
		super();
		this.employeid = employeid;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}
	
	public int getEmployeid() {
		return employeid;
	}
	public void setEmployeid(int employeid) {
		this.employeid = employeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeid=" + employeid + ", name=" + name + ", salary=" + salary + ", address=" + address + "]";
	}
	

}
