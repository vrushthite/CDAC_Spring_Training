package com.cdac.ui;

import java.io.ObjectInputStream.GetField;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	private static ApplicationContext context;
	
	public static ApplicationContext getContext() {
		return context;
	}
	public static void main(String[] args) {
		 context=new ClassPathXmlApplicationContext("Spring-Config.xml");
		Employee employee=context.getBean("employee",Employee.class);
		EmployeeService service=context.getBean("service",EmployeeService.class);
		/*//insert data
		 employee.setEmployeid(222);
		employee.setName("Pooja");
		employee.setSalary(123400);
		
		
		boolean result=service.addEmployee(employee);
		if(result) {
			System.out.println("employee added");
		}else {
			System.out.println("employee unable to add");
		}
		*/
		//Find by id
		Employee findemp=service.findEmployeeById(8);
		if(findemp==null) {
			System.out.println("No such employee present");
		}else {
		System.out.println(findemp);
		}
	/*//Update Operation
		employee.setEmployeid(165);
		employee.setName("praju");
		employee.setSalary(123400);
		boolean result=service.modifyEmployee(employee);
		if(result) {
			System.out.println("Employee is  modified");
		}else {
			System.out.println("Employee is not modified");
		}*/
		//find by id
		Employee emp=service.findEmployeeById(8);
		if(emp==null) {
			System.out.println("No such employee present");
		}else {
		System.out.println(emp);
		}
		/*
		 //display all employee
		List<Employee> emplist=service.findAllEmployees();
		for(Employee list:emplist) {
			System.out.println(list);
		}*/
		boolean result=service.removeEmployee(111);
	
	}
}
