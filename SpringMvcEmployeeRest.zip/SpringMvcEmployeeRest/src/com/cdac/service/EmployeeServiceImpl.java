package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.dao.EmployeeDao;
import com.cdac.model.Employee;
@Service("service")
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao;
	//annotation for declarative transaction
	//7 propagation attribute in declarative transactions, and default-REQUIRED
	// we need to configer bean of TransationManager and this TramsationManager also required datasoure Bean
	@Transactional(propagation =Propagation.REQUIRED ,rollbackFor = Exception.class)
	// Transation rollback only for runtimeException.
	//in dao, Mandatory :> it say that method caller  shoud work in transaction i.e @transational .
	// NEVER :> DO not need to caller in Transaction.
	//REQUIRES_NEW : Always execute new transaction , existing transaction is remove.
	// NOT_SUPPORTED : THIS METHOD is not be in Transaction then use it, 
	// SUPPORTS : Method in Transaction or Not in Transaction does not matter
	//NESTED : IT WILL create nested transaction . if my caller is not in transaction then is work as required
	public boolean addEmployee(Employee employee) {
		int result = getDao().createEmployee(employee);
		if(result == 1) {
			return true;
		}
		return false;
	}
	public Employee findEmployeeById(int employeeId) {
		Employee result = getDao().readEmployeeById(employeeId);
		return result;
	}
	public List<Employee> findAllEmployees() {
		List<Employee> result = getDao().readAllEmployee();
		return result;
	}
	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean modifyEmployee(Employee employee) {
		int result = getDao().updateEmployee(employee);
		if(result == 1) {
			return true;
		}
		return false;
	}
	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean removeEmployee(int employeeId) {
		int result = getDao().deleteEmployee(employeeId);
		if(result == 1) {
			return true;
		}
		return false;
	}
	public EmployeeDao getDao() {
		return dao;
	}
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}
	@Override
	public List<Employee> findAllEmployeesWithAddress() {
		return getDao().findEmployeesWithAddress();
	}

}
