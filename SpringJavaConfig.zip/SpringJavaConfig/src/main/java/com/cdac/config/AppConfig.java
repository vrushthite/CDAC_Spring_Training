package com.cdac.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cdac.model.Address;
import com.cdac.model.Employee;

@Configuration                          //this annotation indicate that it is bean configuration class
public class AppConfig {
	//employee class bean
	@Bean(name="employee")                //name is used to access the employee bean by this name
	@Scope(scopeName="prototype")         //scope=prototype then it is by default lazy
	public Employee getEmployee() {
		Employee employee=new Employee();
		employee.setAddress(getAddress());  //here we implicitly assign the address object to employee object
		return employee;
	}
	//address class bean
	@Bean(name="address")
	@Scope(scopeName="prototype")
	public Address getAddress() {
		Address address=new Address();
		return address;
	}

}
