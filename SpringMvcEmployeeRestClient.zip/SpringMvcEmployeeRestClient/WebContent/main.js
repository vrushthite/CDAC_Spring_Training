function getAllEmployee(){
	var xhr=new XMLHttpRequest();
	xhr.open('GET','http://localhost:8080/SpringMvcEmployeeRest/employees',true);
	xhr.responseType='text';
	xhr.send();
	
	
	xhr.onload=function(){
		if(xhr.status==200){
			var data=JSON.parse(xhr.responseText);
			var tableHTML="<table>";
			tableHTML+="<tr>";
			tableHTML+="<th>Employee Id</th>";
			tableHTML+="<th>Employee Name</th>";
			tableHTML+="<th>Employee Salary</th>";
			tableHTML+="<th>Employee City</th>";
			tableHTML+="<th>Employee Pin</th>";
			tableHTML+="</tr>";
			for(var i=0;i<data.length;i++){
				tableHTML+="<tr>";
				tableHTML+="<td>"+data[i].employeeId+"</td>";
				tableHTML+="<td>"+data[i].employeeName+"</td>";
				tableHTML+="<td>"+data[i].employeeSalary+"</td>";
				tableHTML+="<td>"+data[i].address.city+"</td>";
				tableHTML+="<td>"+data[i].address.pin+"</td>";
				tableHTML+="</tr>";
			}
			tableHTML+="</table>";
			document.getElementById("employeeContainer").innerHTML=tableHTML;
		}
	}
}