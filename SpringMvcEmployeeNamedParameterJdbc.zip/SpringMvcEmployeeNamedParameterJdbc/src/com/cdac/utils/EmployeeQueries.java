package com.cdac.utils;

public interface EmployeeQueries {
	public String INSERT_EMPLOYEE_RECORD="insert into employee2(emp_id,emp_salary,emp_name) values(:emp_id,:emp_name,:emp_salary?)";
	public String GET_EMPLOYEE_BY_ID="select * from employee2 where emp_id=:emp_id";
	public String GET_ALL_EMPLOYEE="select * from employee2";
	public String DELETE_EMPLOYEE_BY_ID="delete from employee2 where emp_id=:emp_id";
	public String UPDATE_EMPLOYEE_BY_ID="update employee2 set emp_name=:emp_name,emp_salary=:emp_salary where emp_id=:emp_id";
	public String GET_EMPLOYEE_WITH_ADDRESS="select emp_id,emp_name,emp_salary,city,street  from employee2,address employee2.address_id=address.address_id";
	
}
