package com.cdac.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("employee")
@Scope(scopeName = "prototype")
public class Employee {
	private int employeid;
	private String name;
	private double salary;
	
	@Autowired
	private Address address;
	
	
	
	public Employee() {
		super();
	}
	
	public Employee(int employeid, String name, double salary, Address address) {
		super();
		this.employeid = employeid;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}
	
	public int getEmployeid() {
		return employeid;
	}
	public void setEmployeid(int employeid) {
		this.employeid = employeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeid=" + employeid + ", name=" + name + ", salary=" + salary + ", address=" + address + "]";
	}
	

}
