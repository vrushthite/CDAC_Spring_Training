package com.cdac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.model.Address;
import com.cdac.model.Employee;
import com.cdac.utils.EmployeeQueries;
@Repository("dao")
public class EmployeeDaoImp implements EmployeeDao{
	@Autowired
	private NamedParameterJdbcTemplate template;
	
	
	public NamedParameterJdbcTemplate getTemplate() {
		return template;
	}
	public void NamedParameterJdbcTemplate(NamedParameterJdbcTemplate template) {
		this.template = template;
	}
	public int createEmployee(Employee employee) {
		Map<String, Object> parameters=new HashMap<>();
		parameters.put("emp_id", employee.getEmployeid());
		parameters.put("employee_name",employee.getName());
		parameters.put("emp_salary", employee.getSalary());
		
		return template.update(EmployeeQueries.INSERT_EMPLOYEE_RECORD,parameters);
	}
	public Employee readEmployeeById (int employeeid) {
		return null;
		
		
	}
	public List<Employee> readAllEmployee() {
		return null;
			
	}
	public int updateEmployee(Employee employee) {
		return 0;
		
	}
	public int deleteEmployee(int employeeid) {
		return employeeid;
	
	}
	@Override
	public List<Employee> findEmployeeByAddress() {
		return null;
	
	}

}
