package com.cdac.dao;

import java.util.List;
import java.util.Map;

import com.cdac.model.Employee;

public interface EmployeeDao {
	public int createEmployee(Employee employee);
	public Employee readEmployeeById(int employeeid);
	public List<Employee> readAllEmployee();
	public int updateEmployee(Employee employee);
	public int deleteEmployee(int employeeid);
	public List<Employee> findEmployeeByAddress();
	
}
