package com.cdac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cdac.model.Employee;

public class EmployeeRowMapper implements RowMapper<Employee>{

	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee=new Employee();
		employee.setName(rs.getString("emp_name"));
		employee.setEmployeid(rs.getInt("emp_id"));
		employee.setSalary(rs.getDouble("emp_salary"));
		return employee;
	}

	
	
}
