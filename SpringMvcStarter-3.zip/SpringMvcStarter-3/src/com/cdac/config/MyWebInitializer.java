package com.cdac.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;


public class MyWebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	//responsible to load service and Dao related beans and register in root application context
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {RootConfig.class};
	}
	//responsible to load spring mvc related bean and register in main application context
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {WebConfig.class};
	}
	
	//route is followed by here
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

}
