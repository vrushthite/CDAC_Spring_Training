package com.cdac.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

@RestController
//http://localhost:8080/SpringMvcEmployeeRest/employee
@RequestMapping(path = "employees")
public class EmployeeRestController {
	@Autowired
	private EmployeeService service;
	//GET->http://localhost:8080/SpringMvcEmployeeRest/employee/1
	@RequestMapping(path = "{Id}",method = RequestMethod.GET,produces =MediaType.APPLICATION_JSON_VALUE)
	public Employee getEmployeeById(@PathVariable("Id") Integer employeeId) {
	Employee result=service.findEmployeeById(employeeId);
	if(result!=null) {
		return result;
	}else {
		return null;
		}
	}
	//GET->http://localhost:8080/SpringMvcEmployeeRest/employee
	@RequestMapping(method = RequestMethod.GET,produces =MediaType.APPLICATION_JSON_VALUE )
	public List<Employee> getAllEmployee(){
		List<Employee> list=service.findAllEmployeesWithAddress();
		return list;
	}
	//POST->http://localhost:8080/SpringMvcEmployeeRest/employee
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
		boolean result=service.addEmployee(employee);
		ResponseEntity<String> responseEntity=null;
		if(result) {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employee.getEmployeeId()+" is added.",HttpStatus.CREATED);
	
		}else {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employee.getEmployeeId()+" is not added.",HttpStatus.INTERNAL_SERVER_ERROR);
		
		}
		return responseEntity;
	}
	@RequestMapping(path = {"Id"},method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteEmployee(@PathVariable("Id") Integer employeeId) {
		System.out.println("delete");
		boolean result=service.removeEmployee(employeeId);
		ResponseEntity<String> responseEntity=null;
		if(result) {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employeeId+" is deleted successfully.",HttpStatus.OK);
	
		}else {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employeeId+" is not deleted.",HttpStatus.INTERNAL_SERVER_ERROR);
		
		}
		return responseEntity;
		
	}
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<String> updateEmployee(@RequestHeader(value="Authorization") String authorization,@RequestBody Employee employee) {
		boolean result=service.modifyEmployee(employee);
		ResponseEntity<String> responseEntity=null;
		if(result) {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employee+" is successfully updated.",HttpStatus.OK);
	
		}else {
			responseEntity=new ResponseEntity<String>( "Employee with employee id= "+employee+" is unable to update.",HttpStatus.INTERNAL_SERVER_ERROR);
		
		}
		return responseEntity;
		
	}

}
