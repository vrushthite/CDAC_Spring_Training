package com.cdac.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloRestController {
	//http://localhost:9090/hello
	@RequestMapping(path = "hello",method = RequestMethod.GET)
	public String sayHello() {
		return "Spring Boot is ready and saying Hello";
	}
}
