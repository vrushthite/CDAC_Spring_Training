package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
//This annotation responsible for configuration,ComonentScan,EnableAutoConfiguration
@SpringBootApplication
public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(MainClass.class, args);
		for(String bean:context.getBeanDefinitionNames()) {
			System.out.println("bean name = "+bean);
		}

	}

}
