package com.cdac.model;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("employee")
@Scope(scopeName="prototype")
@XmlRootElement//create output in xml format to send to other client
public class Employee {
	//NULL value is excluded
	@NotNull(message = "Employee id is required.")
	private Integer employeeId;
	//blank value is excluded
	@NotBlank(message="Employee name should not be blank.")
	private String employeeName;
	
	@Min(value = 5000,message = "Employee salary should be greater than or equal to 5000.")
	@Max(value = 750000,message = "Employee salary should be less than or equal to 750000.")
	private Double employeeSalary;
	
	//For foreign key validation we required to define property using  @Valid Annotation.
	@Autowired 
	@Valid
	private Address address;
	
	public Employee() {
		System.out.println("Employee object created.");
	}
	public Employee(Address address) {
		this.address = address;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(Double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + ", address=" + address + "]";
	}
	
	
}
